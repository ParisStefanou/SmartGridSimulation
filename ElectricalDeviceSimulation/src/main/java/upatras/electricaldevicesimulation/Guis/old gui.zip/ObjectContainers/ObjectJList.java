/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package upatras.electricaldevicesimulation.Guis.ObjectContainers;

import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Paris
 */
public class ObjectJList<T> extends JList implements ObjectContainer {

    Object object = null;
    boolean error = false;
    List<T> objects;
    DefaultListModel model = new DefaultListModel();

    ArrayList<ActionListener> changelisteners = new ArrayList<>();

    public void addListChangeListener(ActionListener a) {
        changelisteners.add(a);
    }

    public ObjectJList(List<T> objects, List<String> names) {
        super();
        for (int i = 0; i < names.size(); i++) {
            model.addElement(names.get(i));
        }
        this.objects = objects;
        setModel(model);
        setSelectedIndex(0);
        setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                update();
            }
        });
        setSize(getPreferredSize());
        update();
    }

    private void update() {
        try {
            object = objects.get(getSelectedIndex());
        } catch (Exception ignore) {
            object = null;
        }
        for (ActionListener a : changelisteners) {
            a.actionPerformed(null);
        }

    }

    @Override
    public T getObject() {

        return (T) object;
    }

}
