/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package upatras.electricaldevicesimulation.Guis.ObjectGeneration;

import org.reflections.Reflections;
import upatras.electricaldevicesimulation.simulationcore.DeviceBase.SingleElectricalDevice;
import upatras.electricaldevicesimulation.simulationcore.Model;
import upatras.electricaldevicesimulation.simulationcore.enviromentbase.AbstractEnvironment;
import upatras.electricaldevicesimulation.simulationcore.enviromentbase.AbstractEnvironmentalModifier;

import java.lang.reflect.Constructor;
import java.lang.reflect.Executable;
import java.lang.reflect.Modifier;
import java.lang.reflect.Parameter;
import java.util.ArrayList;
import java.util.Set;

/**
 *
 * @author Paris
 */
public class ClassScanner<T> {

    Class<T> classtype;

    public ClassScanner(Class<T> classtype) {

        this.classtype = classtype;

    }

    public ArrayList<Class<? extends T>> getallsubclasses() {
        Reflections reflections = new Reflections("");
        Set<Class<? extends T>> classesset = reflections.getSubTypesOf(classtype);
        ArrayList<Class<? extends T>> toreturn = new ArrayList<>();
        for (Class<? extends T> item : classesset) {
            if (!Modifier.isAbstract(item.getModifiers())) {
                toreturn.add(item);
            }
        }
        return toreturn;
    }

    public static ArrayList<Class<? extends SingleElectricalDevice>> getallSingleElectricalDevices() {
        Reflections reflections = new Reflections("");
        Set<Class<? extends SingleElectricalDevice>> classesset = reflections.getSubTypesOf(SingleElectricalDevice.class);
        ArrayList<Class<? extends SingleElectricalDevice>> toreturn = new ArrayList<>();
        for (Class c : classesset) {
            if (!Modifier.isAbstract(c.getModifiers())) {
                toreturn.add(c);
            }
        }

        return toreturn;

    }

    public static ArrayList<Class<? extends Model>> getallModels() {
        Reflections reflections = new Reflections("");
        Set<Class<? extends Model>> classesset = reflections.getSubTypesOf(Model.class);
        ArrayList<Class<? extends Model>> toreturn = new ArrayList<>();
        for (Class c : classesset) {
            if (!Modifier.isAbstract(c.getModifiers())) {
                toreturn.add(c);
            }
        }

        return toreturn;

    }

    public static ArrayList<Class<? extends AbstractEnvironmentalModifier>> getallModifiers() {
        Reflections reflections = new Reflections("");
        Set<Class<? extends AbstractEnvironmentalModifier>> classesset = reflections.getSubTypesOf(AbstractEnvironmentalModifier.class);
        ArrayList<Class<? extends AbstractEnvironmentalModifier>> toreturn = new ArrayList<>();
        for (Class c : classesset) {
            if (!Modifier.isAbstract(c.getModifiers())) {
                toreturn.add(c);
            }
        }

        return toreturn;

    }

    public static ArrayList<Class<? extends AbstractEnvironment>> getallEnviroments() {
        Reflections reflections = new Reflections("");
        Set<Class<? extends AbstractEnvironment>> classesset = reflections.getSubTypesOf(AbstractEnvironment.class);
        ArrayList<Class<? extends AbstractEnvironment>> toreturn = new ArrayList<>();
        for (Class c : classesset) {
            if (!Modifier.isAbstract(c.getModifiers())) {
                toreturn.add(c);
            }
        }

        return toreturn;

    }

    public static Constructor[] getconstructors(Class c) {

        return c.getConstructors();

    }

    public static Parameter[] getparameters(Executable ex) {

        return ex.getParameters();

    }

}
