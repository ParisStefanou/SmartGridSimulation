/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package upatras.electricaldevicesimulation.Guis.ObjectContainers;

import javax.swing.*;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import java.awt.*;

/**
 *
 * @author Paris
 */
public class ObjectJTextField<T> extends JTextField implements ObjectContainer {

    Object object = null;
    boolean error = false;
    Class c;

    public ObjectJTextField(Class<T> c, String s) {
        super(s);
        this.c = c;

        getDocument().addDocumentListener(new DocumentListener() {
            @Override
            public void changedUpdate(DocumentEvent e) {
                update();
            }

            @Override
            public void removeUpdate(DocumentEvent e) {
                update();
            }

            @Override
            public void insertUpdate(DocumentEvent e) {
                update();
            }
        });
        update();
    }

    private void update() {
        try {
            if (c.equals(Integer.class) || c.equals(int.class)) {
                object = Integer.parseInt(getText());
            } else if (c.equals(Long.class) || c.equals(long.class)) {
                object = Long.parseLong(getText());
            } else if (c.equals(Double.class) || c.equals(double.class)) {
                object = Double.parseDouble(getText());
            } else if (c.equals(Float.class) || c.equals(float.class)) {
                object = Float.parseFloat(getText());
            } else if (c.equals(String.class)) {
                object = getText();
            } else {
                error = true;
                object = null;
                return;
            }
            error = false;
        } catch (NumberFormatException ignore) {
            error = true;
            object = null;
        }

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (error) {
            setBackground(Color.red);
        } else {
            setBackground(Color.green);
        }

    }

    @Override
    public T getObject() {

        return (T) object;
    }

}
