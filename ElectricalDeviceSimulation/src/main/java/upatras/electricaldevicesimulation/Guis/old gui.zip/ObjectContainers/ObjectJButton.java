/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package upatras.electricaldevicesimulation.Guis.ObjectContainers;

import upatras.electricaldevicesimulation.guis.ModelObjectPickerFrame;
import upatras.electricaldevicesimulation.simulationcore.Model;
import upatras.utilitylibrary.library.Exceptions.InvalidClassException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Paris
 */
public class ObjectJButton<T> extends JButton implements ObjectContainer {

    Object object = null;
    boolean error = false;
    Model m;
    Class c;

    public ObjectJButton(Class<T> c, Model m, String s) {
        super(s);
        this.c = c;

        getModel().addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    ModelObjectPickerFrame f = new ModelObjectPickerFrame(c, m);
                    f.addobjectselectionlistener(new ActionListener() {
                        @Override
                        public void actionPerformed(ActionEvent e) {
                            object = f.getObject();

                            update();
                        }
                    });
                    f.setVisible(true);
                } catch (InvalidClassException ex) {
                    Logger.getLogger(ObjectJButton.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        });
        update();
    }

    private void update() {
        try {

            if (object != null) {
                error = false;
            } else {
                error = true;
            }
        } catch (Exception ignore) {
            error = true;
            object = null;
        }

    }

    @Override
    public void paint(Graphics g) {
        super.paint(g);
        if (error) {
            setBackground(Color.red);
        } else {
            setBackground(Color.green);
        }

    }

    @Override
    public T getObject() {

        return (T) object;
    }

}
